"""
The app's own update graph, for a front end's graph explorer, behind the request API.

    register_introspection(chart_api)               # the bundled dh_chart_ext.dh_introspect
    register_introspection(chart_api, introspect)   # or another introspect(publish=False) -> report

Method:

  graph  {all?: bool}  -> {nodes: [{id, kind, label, description, variables, parents, ms_per_interval,
                            rows_changed_per_interval, active, reachable_from_scope}], edges: [[from, to]],
                            ancestry_complete, update_graphs, exports: [{name, kind}], took_ms, cached}
         all=false (the default) leaves out engine internals and nodes not reachable from a named variable

The report reads the engine's performance logs (pandas), so a call costs from tens of milliseconds to
seconds on a big graph: replies are cached for `cache_s`. Ancestry (the edges) is only recorded for nodes
built after the ancestors log was opened: open it first thing in the app (perfmon.update_performance_ancestors_log()).
"""
from __future__ import annotations

import threading
import time
from typing import Callable, Optional

from .rpc import Api


def register_introspection(api: Api, introspect: Optional[Callable[..., dict]] = None, *, cache_s: float = 10.0) -> None:
    if introspect is None:
        from .dh_introspect import introspect
    lock = threading.Lock()
    cached: dict = {"at": 0.0, "rep": None}

    def report() -> tuple[dict, bool, int]:
        with lock:
            now = time.monotonic()
            if cached["rep"] is not None and now - cached["at"] < cache_s:
                return cached["rep"], True, 0
            t0 = time.perf_counter()
            rep = introspect(publish=False)
            took = round((time.perf_counter() - t0) * 1000)
            cached.update(at=time.monotonic(), rep=rep)
            return rep, False, took

    @api.method
    def graph(ctx, all: bool = False):  # noqa: A002 (the parameter's name on the wire)
        """The update graph: nodes (with recent cost), edges, and the named variables on them."""
        rep, hit, took = report()
        g = rep.get("graph", {})
        nodes = g.get("nodes", [])
        if not all:
            nodes = [n for n in nodes if n.get("kind") != "internal" and n.get("reachable_from_scope")]
        ids = {n["id"] for n in nodes}
        keep = ("id", "kind", "label", "description", "variables", "parents", "ms_per_interval",
                "rows_changed_per_interval", "active", "reachable_from_scope", "update_graph")
        return {
            "nodes": [{k: n.get(k) for k in keep} | {"parents": [p for p in n.get("parents", []) if p in ids]} for n in nodes],
            "edges": [[p, c] for p, c in g.get("edges", []) if p in ids and c in ids],
            "ancestry_complete": g.get("ancestry_complete"),
            "update_graphs": g.get("update_graphs", []),
            "exports": [{"name": e["name"], "kind": e.get("kind")} for e in rep.get("exports", [])],
            "errors": rep.get("errors", []),
            "took_ms": took,
            "cached": hit,
        }
