"""
A request API for Deephaven apps: handlers registered by name, called by JSON requests over one plugin
message stream per client, answered with JSON and table references. Charts are one set of handlers
(api.ChartApi); an app adds its own.

    api = Api("desk")

    @api.method(tables=True)
    def book(ctx, desk: str, limit: int = 100):
        \"\"\"One desk's book.\"\"\"
        return Reply({"rows": limit}, tables=[book_table.where(f"Desk = `{desk}`").head(limit)])

    desk_api = api          # publish it like a table; clients open type "acme.Api"

Protocol (JSON; one stream per client):
  server -> {"event": "ready", "version": 2, "lease_s": 90, "methods": [...]}   when the stream opens
  client -> {"id": 1, "method": "book", "params": {"desk": "Tech"}}
  server -> {"id": 1, "result": ...}  (+ table references)  or  {"id": 1, "error": "...", "code": "bad_params"}

Built-in methods: hello {token?} (who the user is), describe (methods and parameters), ping (keeps the
lease), release {key} (drop something the stream holds), whoami (the session's auth context).

Handlers get a Context first: ctx.user and ctx.verified (from hello), ctx.hold(key, release) to tie a
resource to the stream (released by release, on close, or when the lease runs out). Parameters are
validated and converted from the handler's type hints (str, int, float, bool, list, dict, Optional);
an unknown or missing parameter is a "bad_params" error.

Identity: hello's token is checked by `identify(token) -> (user, verified)`. The default verifies an
HMAC-signed token (sign_token) when ACME_API_SECRET is set; without a secret it accepts "user:<name>"
unverified (attribution only, as on Community, whose auth context has no user id).

Leases: Deephaven does not always report a closed client (a browser tab that navigates away), so each
stream has a lease renewed by any message; a stream silent for lease_s is closed and its holds released.

Requests run on Deephaven's concurrent executor, one at a time per stream, under the stream's
execution context (so table operations and the caller's auth context work as in the IDE).
"""
from __future__ import annotations

import inspect
import json
import logging
import math
import os
import threading
import time
import traceback
import typing
from queue import SimpleQueue
from types import SimpleNamespace
from typing import Any, Callable, Literal, Optional, Sequence

from deephaven.execution_context import get_exec_ctx
from deephaven.plugin.object_type import BidirectionalObjectType, MessageStream

from .tokens import sign_token, verify_token  # noqa: F401 (re-exported)

log = logging.getLogger(__name__)

TYPE_NAME = "acme.Api"
VERSION = 2
REQUIRED = inspect.Parameter.empty  # Api.add: a parameter without a default


def json_safe(x):
    """JSON-safe, recursively: numpy scalars to Python numbers, NaN and infinities to None."""
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    t = type(x).__module__
    if t == "numpy":  # without importing numpy
        if hasattr(x, "dtype") and x.dtype.kind == "b":
            return bool(x)
        if hasattr(x, "dtype") and x.dtype.kind in "iu":
            return int(x)
        if hasattr(x, "dtype") and x.dtype.kind == "f":
            v = float(x)
            return v if math.isfinite(v) else None
    return x


class ApiError(Exception):
    """An error a handler raises to answer with a code: bad_params, not_found, limit, unauthorized, ..."""

    def __init__(self, message: str, code: str = "error"):
        super().__init__(message)
        self.code = code


class Reply:
    """A handler's answer with tables: Reply(result, tables=[t, ...]). A plain return value has none."""

    def __init__(self, result: Any = None, tables: Optional[list] = None):
        self.result = result
        self.tables = list(tables or [])


# ----------------------------------------------------------------------------- identity

def default_identify(token: Optional[str]) -> tuple[str, bool]:
    """Verified with ACME_API_SECRET when it is set; otherwise 'user:<name>' is taken at its word."""
    secret = os.environ.get("ACME_API_SECRET")
    if not token:
        if secret:
            raise ApiError("a token is required", "unauthorized")
        return "anonymous", False
    if secret:
        user = verify_token(token, secret)
        if user is None:
            raise ApiError("invalid or expired token", "unauthorized")
        return user, True
    if token.startswith("user:") and len(token) > 5:
        return token[5:], False
    raise ApiError("no ACME_API_SECRET on the server: send 'user:<name>' (unverified)", "unauthorized")


def auth_context_info() -> dict:
    """The current thread's Deephaven auth context (Community: Anonymous or SuperUser, no user id)."""
    try:
        ctx = get_exec_ctx().j_exec_ctx.getAuthContext()
        if ctx is None:
            return {"auth": None}
        return {"auth": str(ctx.toString()), "class": str(ctx.getClass().getName())}
    except Exception as e:  # noqa: BLE001
        return {"auth": None, "error": repr(e)}


# ----------------------------------------------------------------------------- parameters

_TYPES = {str: "string", int: "integer", float: "number", bool: "boolean", list: "array", dict: "object"}


def _type_name(tp) -> str:
    origin = typing.get_origin(tp)
    if origin is typing.Union:
        args = [a for a in typing.get_args(tp) if a is not type(None)]
        return " | ".join(_type_name(a) for a in args)
    if origin in (list, tuple, typing.Sequence) or tp in (list, tuple):
        return "array"
    if origin is dict or tp is dict:
        return "object"
    if tp is inspect.Parameter.empty or tp is Any:
        return "any"
    return _TYPES.get(tp, getattr(tp, "__name__", str(tp)))


def _coerce(name: str, value, tp):
    """`value` as `tp`, or ApiError(bad_params)."""
    if tp is inspect.Parameter.empty or tp is Any:
        return value
    origin = typing.get_origin(tp)
    if origin is typing.Union:
        args = typing.get_args(tp)
        if value is None and type(None) in args:
            return None
        errors = []
        for a in args:
            if a is type(None):
                continue
            try:
                return _coerce(name, value, a)
            except ApiError as e:
                errors.append(str(e))
        raise ApiError(f"{name}: {errors[0] if errors else 'bad value'}", "bad_params")
    if origin in (list, tuple, typing.Sequence) or tp in (list, tuple):
        if not isinstance(value, list):
            raise ApiError(f"{name} must be an array", "bad_params")
        return value
    if origin is dict or tp is dict:
        if not isinstance(value, dict):
            raise ApiError(f"{name} must be an object", "bad_params")
        return value
    if tp is bool:
        if not isinstance(value, bool):
            raise ApiError(f"{name} must be true or false", "bad_params")
        return value
    if tp is int:
        if isinstance(value, bool) or not isinstance(value, (int, float)) or int(value) != value:
            raise ApiError(f"{name} must be an integer", "bad_params")
        return int(value)
    if tp is float:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ApiError(f"{name} must be a number", "bad_params")
        return float(value)
    if tp is str:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return str(value)  # "2m" and 120 are both fine where a string is expected
        if not isinstance(value, str):
            raise ApiError(f"{name} must be a string", "bad_params")
        return value
    return value


class _Method:
    def __init__(self, fn: Callable, name: str, tables: bool):
        self.fn = fn
        self.name = name
        self.tables = tables
        sig = inspect.signature(fn)
        hints = typing.get_type_hints(fn)
        self.params = [p for p in list(sig.parameters.values())[1:]]  # the first is the Context
        self.hints = {p.name: hints.get(p.name, inspect.Parameter.empty) for p in self.params}
        self.doc = inspect.getdoc(fn) or ""

    def bind(self, params: dict) -> dict:
        names = {p.name for p in self.params}
        extra = set(params) - names
        if extra:
            raise ApiError(f"unknown parameter(s) {sorted(extra)} for {self.name}", "bad_params")
        out = {}
        for p in self.params:
            if p.name in params:
                out[p.name] = _coerce(p.name, params[p.name], self.hints[p.name])
            elif p.default is inspect.Parameter.empty:
                raise ApiError(f"missing parameter {p.name!r} for {self.name}", "bad_params")
        return out

    def spec(self) -> dict:
        return {
            "name": self.name, "doc": self.doc.split("\n\n")[0], "returns_tables": self.tables,
            "params": [{"name": p.name, "type": _type_name(self.hints[p.name]), "required": p.default is inspect.Parameter.empty,
                        **({} if p.default is inspect.Parameter.empty else {"default": p.default})} for p in self.params],
        }


# ----------------------------------------------------------------------------- the API object

class Context:
    """What a handler knows about its caller, and how it ties resources to the caller's stream."""

    def __init__(self, stream: "_Stream"):
        self._stream = stream

    @property
    def user(self) -> str:
        return self._stream.user

    @property
    def verified(self) -> bool:
        return self._stream.verified

    @property
    def api(self) -> "Api":
        return self._stream.api

    def hold(self, key, release: Callable[[], None]) -> bool:
        """Tie `release` to this stream under `key`: called by a `release` request with that key, when the
        stream closes, or when its lease runs out. A key held again on the same stream keeps one reference
        and counts: it is released after as many `release` requests. False (and release() called now) if the
        stream closed meanwhile. Raises ApiError(limit) past the per-stream or per-user limit."""
        return self._stream.hold(key, release)

    def holding(self) -> list:
        return list(self._stream.held)


class Api:
    """A set of request handlers, published as one Deephaven object (type acme.Api)."""

    def __init__(self, name: str = "api", *, lease_s: float = 90.0,
                 identify: Callable[[Optional[str]], tuple[str, bool]] = default_identify,
                 max_held_per_stream: int = 64, max_held_per_user: int = 256):
        self.name = name
        self.lease_s = lease_s
        self.identify = identify
        self.max_held_per_stream = max_held_per_stream
        self.max_held_per_user = max_held_per_user
        self.methods: dict[str, _Method] = {}
        self._streams: set = set()
        self._lock = threading.Lock()
        self._held_by_user: dict[str, int] = {}
        self._register_builtins()
        threading.Thread(target=self._reap_loop, name=f"{name}-leases", daemon=True).start()

    def method(self, fn: Optional[Callable] = None, *, name: Optional[str] = None, tables: bool = False):
        """Register `fn(ctx, **params)` as a method (by its name, or `name`). tables=True: it may return
        Reply(result, tables=[...])."""
        def register(f):
            m = _Method(f, name or f.__name__, tables)
            self.methods[m.name] = m
            return f

        return register(fn) if fn is not None else register

    def add(self, name: str, fn: Callable[["Context", dict], Any], params: Sequence[tuple] = (), *, doc: str = "",
            tables: bool = False, safe: bool = True):
        """Register `fn(ctx, args)` with its parameters listed, [(name, type, default)] (default REQUIRED: required),
        instead of read from a signature: a parameter may then have any name, `yield` included. With `safe`, the
        reply is made JSON-safe (json_safe; a Reply's result too)."""
        def handler(ctx, **kw):
            out = fn(ctx, kw)
            if not safe:
                return out
            return Reply(json_safe(out.result), tables=out.tables) if isinstance(out, Reply) else json_safe(out)

        m = _Method(handler, name, tables)
        m.params = [SimpleNamespace(name=n, default=d) for n, _t, d in params]
        m.hints = {n: t for n, t, _d in params}
        m.doc = doc
        self.methods[name] = m
        return m

    @property
    def streams(self) -> int:
        with self._lock:
            return len(self._streams)

    def describe(self) -> list[dict]:
        return [m.spec() for m in self.methods.values()]

    # built-in methods

    def _register_builtins(self) -> None:
        @self.method
        def hello(ctx, token: Optional[str] = None):
            """Who the user is: a token the server verifies (or 'user:<name>' unverified, with no secret set)."""
            user, verified = self.identify(token)
            ctx._stream.set_user(user, verified)
            return {"user": user, "verified": verified}

        @self.method
        def describe(ctx):
            """The methods and their parameters."""
            return self.describe()

        @self.method
        def ping(ctx):
            """Keeps the stream's lease."""
            return {"lease_s": self.lease_s}

        @self.method
        def release(ctx, key: list):
            """Release something this stream holds (by the key its request returned)."""
            return {"released": ctx._stream.release(_key(key))}

        @self.method
        def whoami(ctx):
            """The user from hello, and the session's Deephaven auth context."""
            return {"user": ctx.user, "verified": ctx.verified, "auth_at_connect": ctx._stream.auth_at_connect,
                    "auth_in_request": auth_context_info()}

    # bookkeeping shared by streams

    def _add(self, s) -> None:
        with self._lock:
            self._streams.add(s)

    def _remove(self, s) -> None:
        with self._lock:
            self._streams.discard(s)

    def _count_user(self, user: str, delta: int) -> int:
        with self._lock:
            n = self._held_by_user.get(user, 0) + delta
            if n <= 0:
                self._held_by_user.pop(user, None)
            else:
                self._held_by_user[user] = n
            return n

    def _reap_loop(self) -> None:
        while True:
            time.sleep(max(1.0, self.lease_s / 6))
            now = time.monotonic()
            with self._lock:
                stale = [s for s in self._streams if now - s.last_seen > self.lease_s]
            for s in stale:
                print(f"[{self.name}] lease expired: releasing {len(s.held)} hold(s)", flush=True)
                s.expire()


def _key(key) -> Any:
    """A key back from JSON (lists) as the tuple it was."""
    if isinstance(key, list):
        return tuple(_key(x) for x in key)
    return key


def _jsonable(key) -> Any:
    if isinstance(key, tuple):
        return [_jsonable(x) for x in key]
    return key


class _Stream(MessageStream):
    def __init__(self, api: Api, client: MessageStream):
        super().__init__()
        self.api = api
        self.client = client
        self.held: dict = {}  # key -> release
        self.counts: dict = {}  # key -> how many requests hold it (each `release` undoes one)
        self.user = "anonymous"
        self.verified = False
        self.closed = False
        self.lock = threading.Lock()
        self.ctx = get_exec_ctx()  # the session's context, for the worker
        self.auth_at_connect = auth_context_info()
        self.queue: SimpleQueue = SimpleQueue()
        self.running = False
        self.last_seen = time.monotonic()
        api._add(self)

    # identity and holds

    def set_user(self, user: str, verified: bool) -> None:
        with self.lock:
            moved = len(self.held)
            old = self.user
            self.user, self.verified = user, verified
        if moved:
            self.api._count_user(old, -moved)
            self.api._count_user(user, moved)

    def hold(self, key, release: Callable[[], None]) -> bool:
        with self.lock:
            if self.closed:
                closed = True
            else:
                closed = False
                if key in self.held:
                    # held already: the stream keeps one reference to the node and counts the requests, so a
                    # release meant for an earlier request (it can arrive after a newer request for the same
                    # key, e.g. a page that unmounts and remounts) doesn't drop the newer one's hold
                    release()
                    self.counts[key] += 1
                    return True
                if len(self.held) >= self.api.max_held_per_stream:
                    release()
                    raise ApiError(f"this stream holds {len(self.held)} items (limit {self.api.max_held_per_stream})", "limit")
                self.held[key] = release
                self.counts[key] = 1
                user = self.user
        if closed:
            release()
            return False
        if self.api._count_user(user, 1) > self.api.max_held_per_user:
            self.release(key)
            raise ApiError(f"{user} holds too many items (limit {self.api.max_held_per_user})", "limit")
        return True

    def release(self, key) -> bool:
        with self.lock:
            if key not in self.held:
                return False
            self.counts[key] -= 1
            if self.counts[key] > 0:
                return True  # other requests on this stream still hold it
            del self.counts[key]
            fn = self.held.pop(key)
            user = self.user
        if fn is None:
            return False
        self.api._count_user(user, -1)
        fn()
        return True

    # MessageStream: called by the server

    def on_data(self, payload: bytes, references: list[Any]) -> None:
        self.last_seen = time.monotonic()
        self.queue.put(bytes(payload))
        with self.lock:
            if self.running:
                return
            self.running = True
        from deephaven.server.executors import submit_task

        submit_task("concurrent", self._drain)

    def on_close(self) -> None:
        with self.lock:
            if self.closed:
                return
            self.closed = True
            held, self.held = self.held, {}
            self.counts = {}
            user = self.user
        for fn in held.values():
            try:
                fn()
            except Exception:  # noqa: BLE001
                log.exception("release failed")
        if held:
            self.api._count_user(user, -len(held))
        self.api._remove(self)

    def expire(self) -> None:
        """The lease ran out: release everything and close the stream (if the client is still there)."""
        self.on_close()
        try:
            self.client.on_close()
        except Exception:  # noqa: BLE001 (already gone)
            pass

    # the worker: one request at a time, in order

    def _drain(self) -> None:
        with self.ctx:
            while True:
                with self.lock:
                    if self.queue.empty():
                        self.running = False
                        return
                self._handle(self.queue.get())

    def _handle(self, payload: bytes) -> None:
        rid = None
        try:
            try:
                req = json.loads(payload.decode() or "{}")
            except ValueError:
                raise ApiError("not JSON", "bad_request") from None
            if not isinstance(req, dict):
                raise ApiError("a request is an object", "bad_request")
            rid = req.get("id")
            name = req.get("method")
            m = self.api.methods.get(name)
            if m is None:
                raise ApiError(f"unknown method {name!r}", "unknown_method")
            params = req.get("params") or {}
            if not isinstance(params, dict):
                raise ApiError("params must be an object", "bad_params")
            out = m.fn(Context(self), **m.bind(params))
            reply = out if isinstance(out, Reply) else Reply(out)
            self._send({"id": rid, "result": _jsonable(reply.result)}, reply.tables)
        except ApiError as e:
            self._send({"id": rid, "error": str(e), "code": e.code}, [])
        except ValueError as e:  # a handler's validation (unknown symbol, bad resolution, ...)
            self._send({"id": rid, "error": str(e), "code": "bad_params"}, [])
        except Exception as e:  # noqa: BLE001
            code = getattr(e, "api_code", None)  # an exception that names its code (cache.NodeLimit: "limit")
            if code is None:
                log.error("request failed: %s", traceback.format_exc())
            self._send({"id": rid, "error": str(e) if code else f"{type(e).__name__}: {e}", "code": code or "error"}, [])

    def _send(self, msg: dict, refs: list) -> None:
        if not self.closed:
            self.client.on_data(json.dumps(msg).encode(), refs)


class ApiType(BidirectionalObjectType):
    """Registers Api objects with the server (dh_chart_ext._register)."""

    @property
    def name(self) -> str:
        return TYPE_NAME

    @property
    def authorization_export_behavior(self) -> Literal["transform", "manual", "unset"]:
        return "transform"  # exported tables get the viewer's ACLs (identity in Community)

    def is_type(self, obj: Any) -> bool:
        return isinstance(obj, Api)

    def create_client_connection(self, obj: object, connection: MessageStream) -> MessageStream:
        assert isinstance(obj, Api)
        stream = _Stream(obj, connection)
        connection.on_data(json.dumps({"event": "ready", "version": VERSION, "lease_s": obj.lease_s,
                                       "methods": sorted(obj.methods)}).encode(), [])
        return stream
